package com.example.gi.acompanhamento.agendafcil;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.lang.reflect.Array;

public class CadastroPaciente extends AppCompatActivity {

    Spinner ufs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_paciente);

        ufs = (Spinner) findViewById(R.id.spinner1);

        ArrayAdapter adapter = ArrayAdapter.createFromResource(this, R.array.ufs, android.R.layout.simple_spinner_item);
        ufs.setAdapter(adapter);

    }
}