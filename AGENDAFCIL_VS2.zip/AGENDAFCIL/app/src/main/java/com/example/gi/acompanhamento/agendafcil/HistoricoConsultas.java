package com.example.gi.acompanhamento.agendafcil;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HistoricoConsultas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historico_consultas);
    }
}
