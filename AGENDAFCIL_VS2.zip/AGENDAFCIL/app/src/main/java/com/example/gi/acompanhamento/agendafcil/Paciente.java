package com.example.gi.acompanhamento.agendafcil;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Paciente extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paciente);
    }

    public void startAgendaConsultaActivity(View view){
        Intent AgendaconsultaActivity = new Intent(this, AgendaConsulta.class);
        startActivity(AgendaconsultaActivity);
    }

    public void startHistoricoConsultasActivity(View view){
        Intent HistoricoConsultasActivity = new Intent(this, HistoricoConsultas.class);
        startActivity(HistoricoConsultasActivity);
    }

    public void startFilaEsperaActivity(View view){
        Intent FilaEsperaActivity = new Intent(this, FilaEspera.class);
        startActivity(FilaEsperaActivity);
    }
}
